import SwiftUI

struct GuidesView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        NavigationStack {
            List {
                ForEach($appState.guides) { $guide in
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text(guide.category)
                                .font(.caption2.bold())
                                .padding(.horizontal, 8)
                                .padding(.vertical, 2)
                                .background(Color.cyan.opacity(0.2))
                                .foregroundColor(.cyan)
                                .clipShape(Capsule())
                            Spacer()
                            Button(action: {
                                guide.likes += 1
                            }) {
                                Label("\(guide.likes)", systemImage: "hand.thumbsup.fill")
                                    .font(.caption)
                                    .foregroundColor(.cyan)
                            }
                            .buttonStyle(.plain)
                        }
                        Text(guide.title)
                            .font(.headline)
                        Text(guide.subtitle)
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text(guide.content)
                            .font(.caption)
                            .foregroundColor(.primary)
                            .padding(.top, 2)
                    }
                    .padding(.vertical, 6)
                }
            }
            .navigationTitle("Hướng dẫn")
        }
    }
}
