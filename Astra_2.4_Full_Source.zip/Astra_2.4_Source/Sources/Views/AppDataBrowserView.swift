import SwiftUI

struct AppDataBrowserView: View {
    @EnvironmentObject var appState: AppState
    @State private var searchText: String = ""

    var filteredContainers: [AppContainerItem] {
        if searchText.isEmpty { return appState.containers }
        return appState.containers.filter {
            $0.name.localizedCaseInsensitiveContains(searchText) ||
            $0.bundleID.localizedCaseInsensitiveContains(searchText)
        }
    }

    var body: some View {
        NavigationStack {
            List {
                Section(header: Text("Workspace Astra"),
                        footer: Text("Patch và tệp có trong Trên iPhone của tôi")) {
                    NavigationLink(destination: WorkspaceDetailView()) {
                        HStack(spacing: 12) {
                            Image(systemName: "externaldrive.fill.badge.timemachine")
                                .font(.title2)
                                .foregroundColor(.cyan)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Workspace Astra")
                                    .font(.headline)
                                Text("Quản lý cây thư mục patch và gói .3105")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                }

                Section(header: Text("\(filteredContainers.count) dữ liệu ứng dụng (MHA-C2)")) {
                    ForEach(filteredContainers) { container in
                        NavigationLink(destination: ContainerFileBrowserView(container: container)) {
                            HStack(spacing: 12) {
                                Image(systemName: "app.badge.checkmark.fill")
                                    .font(.title2)
                                    .foregroundColor(.blue)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(container.name)
                                        .font(.headline)
                                    Text(container.bundleID)
                                        .font(.caption.monospaced())
                                        .foregroundColor(.secondary)
                                }
                                Spacer()
                                Text("\(container.files.count) mục")
                                    .font(.caption2)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                }
            }
            .searchable(text: $searchText, prompt: "Tìm ứng dụng hoặc bundle identifier")
            .navigationTitle("Duyệt dữ liệu ứng dụng")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        appState.log("Đang phân giải tất cả tên bundle ứng dụng qua MHA-C2...")
                        appState.showToast("Đã phân giải tất cả tên ứng dụng!")
                    }) {
                        Image(systemName: "arrow.clockwise")
                    }
                }
            }
        }
    }
}

struct ContainerFileBrowserView: View {
    @EnvironmentObject var appState: AppState
    let container: AppContainerItem
    @State private var files: [FileEntry] = []
    @State private var showNewFolderAlert = false
    @State private var newItemName = ""

    var body: some View {
        List {
            ForEach(files) { file in
                HStack(spacing: 12) {
                    Image(systemName: file.isDirectory ? "folder.fill" : "doc.text.fill")
                        .foregroundColor(file.isDirectory ? .cyan : .orange)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(file.name)
                            .font(.subheadline.weight(.medium))
                        Text(file.relativePath)
                            .font(.caption2.monospaced())
                            .foregroundColor(.secondary)
                    }
                    Spacer()
                    Text(ByteCountFormatter.string(fromByteCount: file.sizeBytes, countStyle: .file))
                        .font(.caption2)
                        .foregroundColor(.secondary)
                }
                .contextMenu {
                    Button {
                        appState.log("Đã tạo quy tắc patch từ đường dẫn: \(file.relativePath)")
                        appState.showToast("Đã thêm vào dự án Patch!")
                    } label: {
                        Label("Tạo patch (.3105)", systemImage: "shippingbox")
                    }

                    Button {
                        appState.log("Đã nén ZIP mục: \(file.name)")
                        appState.showToast("Đã tạo Lưu trữ.zip!")
                    } label: {
                        Label("Nén ZIP", systemImage: "doc.zipper")
                    }

                    Button {
                        appState.log("Đã thay thế tệp \(file.name) thành công.")
                        appState.showToast("Đã thay thế tệp \(file.name)!")
                    } label: {
                        Label("Thay thế tệp", systemImage: "arrow.triangle.swap")
                    }

                    Button(role: .destructive) {
                        files.removeAll { $0.id == file.id }
                        appState.showToast("Đã xóa \(file.name)")
                    } label: {
                        Label("Xóa", systemImage: "trash")
                    }
                }
            }
        }
        .navigationTitle(container.name)
        .onAppear {
            files = container.files
        }
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(action: { showNewFolderAlert = true }) {
                    Image(systemName: "plus")
                }
            }
        }
        .alert("Tạo thư mục mới", isPresented: $showNewFolderAlert) {
            TextField("Tên", text: $newItemName)
            Button("Hủy", role: .cancel) { newItemName = "" }
            Button("Tạo") {
                guard !newItemName.isEmpty else { return }
                files.append(FileEntry(name: newItemName, relativePath: newItemName, isDirectory: true, sizeBytes: 4096, modifiedDate: Date()))
                appState.showToast("Đã tạo \(newItemName)")
                newItemName = ""
            }
        }
    }
}

struct WorkspaceDetailView: View {
    var body: some View {
        List {
            Section(footer: Text("Astra tạo folder bundle này trong workspace có thể chỉnh sửa. UUID container không bao giờ được lưu.")) {
                Label("com.dts.freefireth", systemImage: "folder.fill.badge.gearshape")
                Label("com.dts.freefiremax", systemImage: "folder.fill.badge.gearshape")
                Label("com.lemon.lvoverseas", systemImage: "folder.fill.badge.gearshape")
                Label("Exports (.3105)", systemImage: "archivebox.fill")
            }
        }
        .navigationTitle("Workspace Astra")
    }
}
