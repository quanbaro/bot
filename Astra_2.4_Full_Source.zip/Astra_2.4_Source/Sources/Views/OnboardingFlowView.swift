import SwiftUI

struct OnboardingFlowView: View {
    @EnvironmentObject var appState: AppState
    @Binding var isCompleted: Bool
    @State private var step: Int = 1

    var body: some View {
        VStack(spacing: 24) {
            HStack {
                Text("Bước \(step) / 3")
                    .font(.caption.bold())
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(Color.cyan.opacity(0.2))
                    .foregroundColor(.cyan)
                    .clipShape(Capsule())
                Spacer()
            }
            .padding(.horizontal)

            Spacer()

            if step == 1 {
                VStack(spacing: 16) {
                    Image(systemName: "sparkles")
                        .font(.system(size: 64))
                        .foregroundColor(.cyan)
                    Text("Chào Mừng Đến Với Astra")
                        .font(.title.bold())
                    Text("Định danh chính thức Astra • Phát triển bởi YangJiii")
                        .font(.subheadline)
                        .foregroundColor(.secondary)

                    Picker("Chọn ngôn ngữ", selection: $appState.language) {
                        ForEach(AppLanguage.allCases) { lang in
                            Text(lang.rawValue).tag(lang)
                        }
                    }
                    .pickerStyle(.segmented)
                    .padding(.top, 12)
                }
                .padding()
            } else if step == 2 {
                VStack(alignment: .leading, spacing: 14) {
                    Text("Yêu cầu chứng chỉ")
                        .font(.title2.bold())
                    Text("• Hoạt động với chứng chỉ doanh nghiệp, bao gồm eSign và các bản cài enterprise tương tự.")
                        .foregroundColor(.green)
                    Text("• Không hoạt động với SideStore, AltStore, 3uTools hoặc LiveContainer.")
                        .foregroundColor(.orange)
                    Text("• Trên iOS 16 đến iOS 18.8.x, Astra sẽ không hoạt động nếu thiết bị đã jailbreak.")
                        .foregroundColor(.secondary)
                }
                .padding()
            } else {
                VStack(alignment: .leading, spacing: 14) {
                    Text("Phiên bản iOS được hỗ trợ")
                        .font(.title2.bold())
                    Text("• Ghi trực tiếp: iOS 16.0–18.7.1 và iOS 26.0–26.6.1.")
                    Text("• AirLift + file pair máy tính: iOS 18.7.2–18.8.x và iOS 26.6.2+.")
                    Text("• Các build iOS 27 còn tương thích đến 27.2 beta 2.")
                        .foregroundColor(.cyan)
                }
                .padding()
            }

            Spacer()

            Button(action: {
                if step < 3 {
                    step += 1
                } else {
                    isCompleted = true
                }
            }) {
                Text(step < 3 ? "Tiếp theo" : "Hoàn thành")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
            }
            .buttonStyle(.borderedProminent)
            .tint(.cyan)
            .padding(.horizontal)
        }
        .padding(.vertical)
    }
}
