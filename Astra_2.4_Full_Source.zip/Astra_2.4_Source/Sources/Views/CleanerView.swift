import SwiftUI

struct CleanerView: View {
    @EnvironmentObject var appState: AppState
    @State private var showConfirmAlert = false

    var totalCleanableMB: Double {
        appState.containers
            .filter { $0.isSelectedForClean }
            .reduce(0) { $0 + $1.cacheSizeMB }
    }

    var body: some View {
        NavigationStack {
            List {
                Section(header: Text("Có thể giải phóng"),
                        footer: Text("Chỉ xóa Library/Caches và tmp. Documents, tùy chọn và Keychain được giữ nguyên.")) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(String(format: "%.1f MB", totalCleanableMB))
                                .font(.system(size: 32, weight: .bold, design: .rounded))
                                .foregroundColor(.cyan)
                            Text("\(appState.containers.filter { $0.isSelectedForClean }.count) ứng dụng có dữ liệu tạm đã chọn")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                        Button(action: { showConfirmAlert = true }) {
                            Text("Dọn ngay")
                                .fontWeight(.bold)
                                .padding(.horizontal, 14)
                                .padding(.vertical, 8)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(.cyan)
                        .disabled(totalCleanableMB <= 0)
                    }
                    .padding(.vertical, 6)
                }

                Section(header: Text("Danh sách ứng dụng")) {
                    ForEach($appState.containers) { $item in
                        Toggle(isOn: $item.isSelectedForClean) {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(item.name)
                                    .font(.headline)
                                Text(String(format: "%.1f MB trong Library/Caches & tmp", item.cacheSizeMB))
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                }
            }
            .navigationTitle("Dọn dẹp")
            .alert("Xóa dữ liệu tạm?", isPresented: $showConfirmAlert) {
                Button("Hủy", role: .cancel) {}
                Button("Dọn ngay", role: .destructive) {
                    let freed = totalCleanableMB
                    for i in appState.containers.indices {
                        if appState.containers[i].isSelectedForClean {
                            appState.containers[i].cacheSizeMB = 0.0
                        }
                    }
                    appState.log(String(format: "Cleaner: Đã giải phóng %.1f MB từ Library/Caches và tmp.", freed))
                    appState.showToast(String(format: "Đã dọn xong %.1f MB!", freed))
                }
            } message: {
                Text("Astra sẽ xóa vĩnh viễn Library/Caches và tmp của các ứng dụng đã chọn. Hãy đóng các ứng dụng đó trước.")
            }
        }
    }
}
