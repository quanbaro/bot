import SwiftUI

struct WallpaperLabView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        NavigationStack {
            List {
                Section(header: Text("Quyền PosterBoard"),
                        footer: Text("Sau khi áp dụng, mở đa nhiệm và vuốt lên để đóng PosterBoard. Hình nền sẽ hoạt động. Chỉ thêm descriptor mới, không thay thế Collections.")) {
                    HStack {
                        Label("com.apple.PosterBoard", systemImage: "sparkles.rectangle.stack.fill")
                        Spacer()
                        Text("Sẵn sàng cài đặt")
                            .foregroundColor(.green)
                            .font(.caption.bold())
                    }
                    HStack {
                        Text("Thế hệ kho dữ liệu")
                        Spacer()
                        Text("Kho 61 · 3 extension · 9 hình nền")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }

                Section(header: Text("Gói đã nhập (.tendies)"),
                        footer: Text("Chọn một gói để cài. Khôi phục chỉ xóa các thư mục descriptor do đúng lần cài Astra đó tạo ra.")) {
                    ForEach($appState.wallpaperPackages) { $pkg in
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(pkg.name)
                                    .font(.headline)
                                Text("\(pkg.descriptorCount) descriptor · \(pkg.sizeString)")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            Button(action: {
                                pkg.isInstalled.toggle()
                                if pkg.isInstalled {
                                    appState.log("Wallpaper Lab: Đã cài đặt \(pkg.name) vào com.apple.PosterBoard.")
                                    appState.showToast("Đã cài hình nền \(pkg.name)!")
                                } else {
                                    appState.log("Wallpaper Lab: Đã khôi phục descriptor của \(pkg.name).")
                                    appState.showToast("Đã khôi phục lần cài!")
                                }
                            }) {
                                Text(pkg.isInstalled ? "Khôi phục" : "Áp dụng")
                                    .font(.caption.bold())
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(pkg.isInstalled ? .orange : .cyan)
                        }
                        .padding(.vertical, 4)
                    }
                }

                Section {
                    Button(action: {
                        let newPkg = WallpaperPackage(name: "Astra_Custom_\(appState.wallpaperPackages.count + 1).tendies", descriptorCount: 2, sizeString: "19.5 MB", isInstalled: false)
                        appState.wallpaperPackages.append(newPkg)
                        appState.showToast("Đã nhập và xác minh gói .tendies!")
                    }) {
                        Label("Nhập gói .tendies", systemImage: "plus.rectangle.on.folder.fill")
                    }

                    Button(role: .destructive, action: {
                        for i in appState.wallpaperPackages.indices {
                            appState.wallpaperPackages[i].isInstalled = false
                        }
                        appState.showToast("Đã reset toàn bộ hình nền do Astra thêm!")
                    }) {
                        Label("Reset hình nền Astra", systemImage: "trash")
                    }
                }
            }
            .navigationTitle("Wallpaper Lab")
        }
    }
}
