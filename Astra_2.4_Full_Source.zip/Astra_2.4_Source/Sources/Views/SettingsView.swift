import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var appState: AppState
    @State private var generatedToken: String = ""

    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Thông tin phiên bản & Tương thích"),
                        footer: Text("Ghi trực tiếp: iOS 16.0–18.7.1 và iOS 26.0–26.6.1. AirLift + file pair máy tính: iOS 18.7.2–18.8.x và iOS 26.6.2+ (gồm 26.7). iOS 27 còn tương thích đến 27.2 beta 2.")) {
                    HStack {
                        Text("Phiên bản hiện tại")
                        Spacer()
                        Text("Astra 2.4.2 (242)").foregroundColor(.secondary)
                    }
                    HStack {
                        Text("Bundle Identifier")
                        Spacer()
                        Text("com.astra.app").font(.caption.monospaced()).foregroundColor(.cyan)
                    }
                    Picker("Ngôn ngữ", selection: $appState.language) {
                        ForEach(AppLanguage.allCases) { lang in
                            Text(lang.rawValue).tag(lang)
                        }
                    }
                }

                Section(header: Text("Token Sandbox"),
                        footer: Text("Khả dụng sau khi exploit cấp quyền thành công.")) {
                    if !generatedToken.isEmpty {
                        Text(generatedToken)
                            .font(.caption2.monospaced())
                            .foregroundColor(.green)
                    }
                    Button("Tạo token sandbox") {
                        generatedToken = "com.apple.app-sandbox.read-write:" + UUID().uuidString.lowercased()
                        appState.showToast("Đã tạo Sandbox Token!")
                    }
                }

                Section(header: Text("Ghi công (Credits)")) {
                    CreditRow(name: "YangJiii", role: "Nhà phát triển & thiết kế Astra")
                    CreditRow(name: "opa334", role: "Dopamine jailbreak, nền tảng kexploit")
                    CreditRow(name: "Seo", role: "Bản chuyển kexploit_opa334")
                    CreditRow(name: "FilzaSlop", role: "Nền tảng sandbox escape, MHA-C2 & dò dữ liệu ứng dụng")
                    CreditRow(name: "Pocket Poster & Nugget", role: "Định dạng hình nền .tendies")
                }

                Section(header: Text("Mạng Xã Hội & Cộng Đồng")) {
                    Link(destination: URL(string: "https://t.me/ioscrackvn")!) {
                        Label("Cộng Đồng IOSVN (Telegram)", systemImage: "paperplane.fill")
                    }
                }
            }
            .navigationTitle("Cài đặt")
        }
    }
}

struct CreditRow: View {
    let name: String
    let role: String
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(name).font(.subheadline.bold())
            Text(role).font(.caption).foregroundColor(.secondary)
        }
    }
}
