import SwiftUI

struct PatchProjectsView: View {
    @EnvironmentObject var appState: AppState
    @State private var showCreatePatch = false
    @State private var searchText = ""

    var body: some View {
        NavigationStack {
            List {
                ForEach($appState.patchProjects) { $project in
                    if searchText.isEmpty ||
                        project.name.localizedCaseInsensitiveContains(searchText) ||
                        project.targetBundle.localizedCaseInsensitiveContains(searchText) {
                        NavigationLink(destination: PatchProjectDetailView(project: $project)) {
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text(project.name)
                                        .font(.headline)
                                    if project.isPrivate {
                                        Image(systemName: "lock.fill")
                                            .font(.caption)
                                            .foregroundColor(.orange)
                                    }
                                    Spacer()
                                    Text(project.isApplied ? "ĐANG BẬT" : "SẴN SÀNG")
                                        .font(.caption2.bold())
                                        .padding(.horizontal, 8)
                                        .padding(.vertical, 3)
                                        .background(project.isApplied ? Color.green.opacity(0.2) : Color.secondary.opacity(0.15))
                                        .foregroundColor(project.isApplied ? .green : .secondary)
                                        .clipShape(Capsule())
                                }
                                Text(project.isPrivate ? "Nội dung riêng tư đã được ẩn" : project.targetBundle)
                                    .font(.caption.monospaced())
                                    .foregroundColor(.cyan)
                                Text("Tác giả: \(project.author) • \(project.rules.count) quy tắc thay thế")
                                    .font(.caption2)
                                    .foregroundColor(.secondary)
                            }
                            .padding(.vertical, 4)
                        }
                    }
                }
            }
            .searchable(text: $searchText, prompt: "Tìm kiếm patch")
            .navigationTitle("Patch (.3105)")
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    Button(action: {
                        appState.log("Đã nhập gói .3105 vào thư viện Patch.")
                        appState.showToast("Đã nhập gói .3105!")
                    }) {
                        Image(systemName: "square.and.arrow.down")
                    }
                    Button(action: { showCreatePatch = true }) {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: $showCreatePatch) {
                CreatePatchProjectView()
                    .environmentObject(appState)
            }
        }
    }
}

struct PatchProjectDetailView: View {
    @EnvironmentObject var appState: AppState
    @Binding var project: PatchProject
    @State private var unlocked: Bool = false
    @State private var passwordInput: String = ""

    var body: some View {
        Form {
            Section(header: Text("Thông tin dự án")) {
                HStack {
                    Text("Tên dự án")
                    Spacer()
                    Text(project.name).foregroundColor(.secondary)
                }
                HStack {
                    Text("Tác giả")
                    Spacer()
                    Text(project.author).foregroundColor(.secondary)
                }
                HStack {
                    Text("Bundle đích")
                    Spacer()
                    Text(project.isPrivate && !unlocked ? "Đã ẩn (Patch riêng tư)" : project.targetBundle)
                        .font(.caption.monospaced())
                        .foregroundColor(.cyan)
                }
                HStack {
                    Text("Quyền riêng tư")
                    Spacer()
                    Text(project.isPrivate ? "Patch riêng tư (.3105)" : "Công khai")
                }
            }

            if project.isPasswordProtected && !unlocked {
                Section(header: Text("Mở khóa gói .3105"),
                        footer: Text("Sau khi mở khóa thành công, thiết bị này chỉ nhớ khóa nội dung, không lưu mật khẩu.")) {
                    SecureField("Nhập mật khẩu (ví dụ: 3105)", text: $passwordInput)
                    Button("Mở khóa") {
                        if passwordInput == project.passwordHash || !project.isPasswordProtected {
                            unlocked = true
                            appState.showToast("Đã mở khóa dự án patch!")
                        } else {
                            appState.showToast("Sai mật khẩu.")
                        }
                    }
                }
            } else {
                Section(header: Text("Quy tắc thay thế (\(project.rules.count))"),
                        footer: Text("Mọi bundle identifier và đường dẫn tương đối sẽ được kiểm tra lại. File gốc được sao lưu trước lần ghi đầu tiên.")) {
                    ForEach(project.rules) { rule in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(rule.destinationRelativePath)
                                .font(.caption.monospaced())
                                .foregroundColor(.primary)
                            Text("Tệp thay thế: \(rule.replacementFileName) (\(rule.fileSize) B)")
                                .font(.caption2)
                                .foregroundColor(.cyan)
                        }
                    }
                }
            }

            Section(header: Text("Thao tác thực thi"),
                    footer: Text("Không thể Apply chồng khi patch đang hoạt động. Hãy đóng app/game đích trước khi đặt lại hoặc khôi phục file.")) {
                Button(action: {
                    project.isApplied = true
                    appState.log("Đã áp dụng patch [\(project.name)] và sao lưu các file gốc.")
                    appState.showToast("Đã áp dụng mọi quy tắc và sao lưu file gốc!")
                }) {
                    Label("Áp dụng patch", systemImage: "play.fill")
                        .fontWeight(.semibold)
                }
                .disabled(project.isApplied)

                Button(action: {
                    appState.log("Đã đặt lại mọi file về trạng thái của gói [\(project.name)] lúc Apply.")
                    appState.showToast("Đã đặt lại theo gói .3105!")
                }) {
                    Label("Đặt lại theo gói", systemImage: "arrow.uturn.backward")
                }

                Button(role: .destructive, action: {
                    project.isApplied = false
                    appState.log("Đã khôi phục các file gốc cho bundle \(project.targetBundle).")
                    appState.showToast("Đã khôi phục các file gốc!")
                }) {
                    Label("Khôi phục file gốc", systemImage: "clock.arrow.circlepath")
                }

                Button(action: {
                    appState.log("Đã xuất gói \(project.name).3105.")
                    appState.showToast("Đã xuất gói .3105!")
                }) {
                    Label("Xuất .3105", systemImage: "square.and.arrow.up")
                }
            }
        }
        .navigationTitle(project.name)
    }
}

struct CreatePatchProjectView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) var dismiss
    @State private var name = ""
    @State private var author = "YangJiii"
    @State private var targetBundle = "com.dts.freefireth"
    @State private var relativePath = "Documents/config.bin"
    @State private var replacementName = "patched_config.bin"
    @State private var isPrivate = false
    @State private var password = ""

    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Dự án mới"),
                        footer: Text("Hãy dùng bundle identifier, ví dụ com.lemon.lvoverseas. Không dán UUID container hoặc đường dẫn /var tuyệt đối.")) {
                    TextField("Tên dự án", text: $name)
                    TextField("Tác giả (không bắt buộc)", text: $author)
                    TextField("Bundle đích", text: $targetBundle)
                }

                Section(header: Text("Quyền riêng tư & Mật khẩu")) {
                    Toggle("Patch riêng tư (Ẩn đường dẫn & bundle)", isOn: $isPrivate)
                    SecureField("Mật khẩu bảo vệ (.3105)", text: $password)
                }

                Section(header: Text("Quy tắc đầu tiên")) {
                    TextField("Đường dẫn tương đối", text: $relativePath)
                    TextField("Tệp thay thế", text: $replacementName)
                }
            }
            .navigationTitle("Tạo patch")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Hủy") { dismiss() }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Lưu") {
                        let newProject = PatchProject(
                            name: name.isEmpty ? "New Patch Project" : name,
                            author: author,
                            targetBundle: targetBundle,
                            isPrivate: isPrivate,
                            isPasswordProtected: !password.isEmpty,
                            passwordHash: password,
                            isApplied: false,
                            rules: [
                                PatchRule(targetBundle: targetBundle, destinationRelativePath: relativePath, replacementFileName: replacementName, fileSize: 16384)
                            ]
                        )
                        appState.patchProjects.append(newProject)
                        appState.showToast("Đã tạo dự án patch!")
                        dismiss()
                    }
                }
            }
        }
    }
}
