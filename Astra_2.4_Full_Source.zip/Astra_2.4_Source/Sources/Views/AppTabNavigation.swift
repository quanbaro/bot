import SwiftUI

struct AppTabNavigation: View {
    @EnvironmentObject var appState: AppState
    @State private var selectedTab: Int = 0

    var body: some View {
        ZStack(alignment: .top) {
            TabView(selection: $selectedTab) {
                DashboardView()
                    .tabItem {
                        Label("Hệ thống", systemImage: "cpu.fill")
                    }
                    .tag(0)

                AppDataBrowserView()
                    .tabItem {
                        Label("Tệp", systemImage: "folder.fill")
                    }
                    .tag(1)

                PatchProjectsView()
                    .tabItem {
                        Label("Patch", systemImage: "shippingbox.fill")
                    }
                    .tag(2)

                if appState.showCleanerTab {
                    CleanerView()
                        .tabItem {
                            Label("Dọn dẹp", systemImage: "paintbrush.fill")
                        }
                        .tag(3)
                }

                if appState.showWallpapersTab {
                    WallpaperLabView()
                        .tabItem {
                            Label("Hình nền", systemImage: "photo.stack.fill")
                        }
                        .tag(4)
                }

                GuidesView()
                    .tabItem {
                        Label("Hướng dẫn", systemImage: "book.fill")
                    }
                    .tag(5)

                SettingsView()
                    .tabItem {
                        Label("Cài đặt", systemImage: "gearshape.fill")
                    }
                    .tag(6)
            }
            .tint(.cyan)

            if let toast = appState.toastMessage {
                HStack(spacing: 10) {
                    Image(systemName: "checkmark.seal.fill")
                        .foregroundColor(.cyan)
                    Text(toast)
                        .font(.subheadline.weight(.semibold))
                        .foregroundColor(.white)
                    Spacer()
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .stroke(LinearGradient(colors: [.cyan.opacity(0.7), .purple.opacity(0.3)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1)
                )
                .padding(.horizontal, 20)
                .padding(.top, 8)
                .transition(.move(edge: .top).combined(with: .opacity))
                .zIndex(999)
            }
        }
    }
}
