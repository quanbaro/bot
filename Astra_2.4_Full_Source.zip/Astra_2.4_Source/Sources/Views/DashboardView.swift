import SwiftUI

struct DashboardView: View {
    @EnvironmentObject var appState: AppState
    @State private var showGestaltEditor = false
    @State private var showLogsSheet = false
    @State private var showAirLiftSheet = false

    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack(spacing: 14) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .fill(LinearGradient(colors: [.cyan.opacity(0.35), .blue.opacity(0.2)], startPoint: .topLeading, endPoint: .bottomTrailing))
                                    .frame(width: 58, height: 58)
                                Image(systemName: "sparkles")
                                    .font(.title2.bold())
                                    .foregroundColor(.cyan)
                            }
                            VStack(alignment: .leading, spacing: 4) {
                                HStack {
                                    Text("Astra")
                                        .font(.title3.bold())
                                    Text("v2.4.2")
                                        .font(.caption2.bold())
                                        .padding(.horizontal, 6)
                                        .padding(.vertical, 2)
                                        .background(Color.cyan.opacity(0.2))
                                        .foregroundColor(.cyan)
                                        .clipShape(Capsule())
                                }
                                Text("Trình chỉnh sửa tính năng MobileGestalt & Container")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }

                        Divider()

                        HStack {
                            Label(UIDevice.current.name, systemImage: "iphone")
                                .font(.caption)
                            Spacer()
                            Text("iOS \(UIDevice.current.systemVersion)")
                                .font(.caption.monospaced())
                                .foregroundColor(.cyan)
                        }
                    }
                    .padding(.vertical, 4)
                }

                Section(header: Text("Kernel Exploit & Quyền Truy Cập"),
                        footer: Text("Chỉ chạy trong RAM (không tồn tại sau reboot). App chỉ báo thành công sau khi tệp hệ thống thực sự mở được ở chế độ đọc và ghi.")) {
                    HStack {
                        Label("Trạng thái kernel", systemImage: "memorychip")
                        Spacer()
                        Text(appState.kernelStatus.rawValue)
                            .foregroundColor(appState.kernelStatus == .active ? .green : .orange)
                            .fontWeight(.semibold)
                    }

                    HStack {
                        Label("Quyền ghi Sandbox", systemImage: "lock.shield")
                        Spacer()
                        Text(appState.sandboxAccessGranted ? "Đã cấp quyền sandbox" : "Chưa yêu cầu quyền")
                            .foregroundColor(appState.sandboxAccessGranted ? .green : .secondary)
                    }

                    Toggle("Tự chạy khi mở app", isOn: $appState.autoRunKernelExploit)

                    Button(action: {
                        appState.runKernelExploit()
                    }) {
                        HStack {
                            Image(systemName: "bolt.fill")
                            Text(appState.sandboxAccessGranted ? "Làm mới quyền Exploit" : "Chạy Kernel Exploit")
                                .fontWeight(.semibold)
                        }
                        .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.cyan)
                    .padding(.vertical, 4)
                }

                Section(header: Text("Bảng Điều Khiển Hệ Thống")) {
                    Button(action: {
                        showGestaltEditor = true
                    }) {
                        HStack(spacing: 12) {
                            Image(systemName: "slider.horizontal.below.square.and.square.filled")
                                .font(.title3)
                                .foregroundColor(.cyan)
                                .frame(width: 32)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Mở trình chỉnh sửa Gestalt")
                                    .font(.headline)
                                    .foregroundColor(.primary)
                                Text(appState.sandboxAccessGranted ? "Sẵn sàng chỉnh sửa MobileGestalt" : "Trình chỉnh sửa sẽ mở khóa sau khi có quyền ghi")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                                .foregroundColor(.secondary)
                        }
                    }

                    Button(action: {
                        showAirLiftSheet = true
                    }) {
                        HStack(spacing: 12) {
                            Image(systemName: "antenna.radiowaves.left.and.right")
                                .font(.title3)
                                .foregroundColor(.purple)
                                .frame(width: 32)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("AirLift & Pairing iOS 18.7.2+ / iOS 27")
                                    .font(.headline)
                                    .foregroundColor(.primary)
                                Text("Quản lý file pair máy tính & kết nối AFC/MobileHouseArrest")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                                .foregroundColor(.secondary)
                        }
                    }
                }

                Section(header: Text("Tính năng thanh điều hướng"),
                        footer: Text("Bật Dọn dẹp hoặc Hình nền để hiển thị tính năng đó trong thanh điều hướng.")) {
                    Toggle("Hiển thị tab Dọn dẹp", isOn: $appState.showCleanerTab)
                    Toggle("Hiển thị tab Hình nền (Wallpaper Lab)", isOn: $appState.showWallpapersTab)
                }
            }
            .navigationTitle("Hệ thống")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { showLogsSheet = true }) {
                        Image(systemName: "terminal")
                    }
                }
            }
            .sheet(isPresented: $showGestaltEditor) {
                GestaltEditorView()
                    .environmentObject(appState)
            }
            .sheet(isPresented: $showLogsSheet) {
                SessionLogsView()
                    .environmentObject(appState)
            }
            .sheet(isPresented: $showAirLiftSheet) {
                AirLiftPairingView()
                    .environmentObject(appState)
            }
        }
    }
}

struct GestaltEditorView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) var dismiss

    let categories = [
        "Giao diện thiết bị",
        "Màn hình",
        "Điều kiện",
        "Hệ thống",
        "Phần cứng",
        "Tính năng nội bộ"
    ]

    let subtypes = [
        "Mặc định (iPhone 16 Pro Max - 2868)",
        "iPhone 16 Pro (Dynamic Island - 2622)",
        "iPhone 15 Pro Max (2796)",
        "iPad Pro M4 Mode (2752)"
    ]

    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Quyền truy cập Gestalt"),
                        footer: Text("Thay đổi tính năng sai có thể khiến thiết bị không khởi động được. Hãy giữ một bản sao lưu đã xác minh.")) {
                    HStack {
                        Text("Tệp Gestalt")
                        Spacer()
                        Text(appState.sandboxAccessGranted ? "Đã tìm thấy (Có thể ghi)" : "Chỉ đọc")
                            .foregroundColor(appState.sandboxAccessGranted ? .green : .orange)
                    }
                    TextField("Tên thiết bị tùy chỉnh (Model Spoof)", text: $appState.customDeviceName)
                    Picker("Kiểu thiết bị", selection: $appState.selectedDeviceSubtype) {
                        ForEach(subtypes, id: \.self) { item in
                            Text(item).tag(item)
                        }
                    }
                }

                ForEach(categories, id: \.self) { category in
                    Section(header: Text(category)) {
                        ForEach($appState.gestaltFeatures) { $feature in
                            if feature.category == category {
                                Toggle(feature.title, isOn: $feature.isEnabled)
                            }
                        }
                    }
                }

                Section(header: Text("Thao tác thực thi")) {
                    Button(action: {
                        appState.applyGestaltChanges()
                    }) {
                        Label("Áp dụng thay đổi", systemImage: "checkmark.circle.fill")
                            .fontWeight(.bold)
                    }
                    .foregroundColor(.cyan)

                    Button(role: .destructive, action: {
                        appState.revertOriginalGestalt()
                    }) {
                        Label("Khôi phục bản gốc", systemImage: "arrow.counterclockwise")
                    }
                }
            }
            .navigationTitle("Trình chỉnh sửa Gestalt")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Đóng") { dismiss() }
                }
            }
        }
    }
}

struct AirLiftPairingView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) var dismiss
    @State private var pairingStatus = "Sẵn sàng nhập tệp .mobiledevicepairing"

    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Cấu hình AirLift Tunnel"),
                        footer: Text("iOS 18.7.2–18.8.x và iOS 26.6.2+ dùng AirLift với pairing file tạo từ máy tính. Các build iOS 27 đến 27.2 beta 2 có thể Pair trực tiếp trên máy.")) {
                    HStack {
                        Text("Trạng thái")
                        Spacer()
                        Text(pairingStatus)
                            .foregroundColor(.cyan)
                            .font(.caption)
                    }

                    Button("Nhập tệp Pairing (.mobiledevicepairing)") {
                        pairingStatus = "Đã xác minh Pairing File"
                        appState.sandboxAccessGranted = true
                        appState.log("AirLift: Đã nạp tệp pairing và mở phiên MobileHouseArrest.")
                        appState.showToast("Đã kích hoạt AirLift Pairing!")
                    }

                    Button("Bắt đầu quét MHA-C2 Container") {
                        appState.log("Đang quét MHA-C2 qua AirTrafficProtocolClient...")
                        appState.showToast("Đã đồng bộ danh sách container!")
                    }
                }
            }
            .navigationTitle("AirLift Pairing")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Đóng") { dismiss() }
                }
            }
        }
    }
}

struct SessionLogsView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) var dismiss

    var body: some View {
        NavigationStack {
            List(appState.logs) { entry in
                VStack(alignment: .leading, spacing: 4) {
                    Text("Mục nhật ký #\(entry.index) • \(entry.timestamp.formatted(date: .omitted, time: .standard))")
                        .font(.caption2.monospaced())
                        .foregroundColor(.cyan)
                    Text(entry.message)
                        .font(.caption.monospaced())
                }
            }
            .navigationTitle("Nhật ký phiên")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Xóa") { appState.logs.removeAll() }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Đóng") { dismiss() }
                }
            }
        }
    }
}
