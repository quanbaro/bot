import Foundation
import SwiftUI
import Combine

enum ExploitStatus: String {
    case inactive = "Chưa hoạt động"
    case running = "Đang kích hoạt…"
    case active = "Đã hoạt động"
    case failed = "Thất bại"
}

enum AppLanguage: String, CaseIterable, Identifiable {
    case vi = "Tiếng Việt"
    case en = "English"
    case zh = "简体中文"
    var id: String { rawValue }
}

struct GestaltFeature: Identifiable {
    let id = UUID()
    let key: String
    let title: String
    let category: String
    var isEnabled: Bool
}

struct AppContainerItem: Identifiable {
    let id = UUID()
    let bundleID: String
    let name: String
    var cacheSizeMB: Double
    var isSelectedForClean: Bool = true
    var files: [FileEntry]
}

struct FileEntry: Identifiable, Hashable {
    let id = UUID()
    var name: String
    var relativePath: String
    var isDirectory: Bool
    var sizeBytes: Int64
    var modifiedDate: Date
}

struct PatchRule: Identifiable, Codable, Hashable {
    var id = UUID()
    var targetBundle: String
    var destinationRelativePath: String
    var replacementFileName: String
    var fileSize: Int64
}

struct PatchProject: Identifiable, Codable {
    var id = UUID()
    var name: String
    var author: String
    var targetBundle: String
    var isPrivate: Bool
    var isPasswordProtected: Bool
    var passwordHash: String
    var isApplied: Bool
    var rules: [PatchRule]
}

struct WallpaperPackage: Identifiable {
    let id = UUID()
    var name: String
    var descriptorCount: Int
    var sizeString: String
    var isInstalled: Bool
}

struct GuideItem: Identifiable {
    let id = UUID()
    let title: String
    let subtitle: String
    let category: String
    let content: String
    var likes: Int
}

struct SessionLogEntry: Identifiable {
    let id = UUID()
    let index: Int
    let timestamp: Date
    let message: String
}

final class AppState: ObservableObject {
    @Published var kernelStatus: ExploitStatus = .inactive
    @Published var sandboxAccessGranted: Bool = false
    @Published var autoRunKernelExploit: Bool = false
    @Published var showCleanerTab: Bool = true
    @Published var showWallpapersTab: Bool = true
    @Published var language: AppLanguage = .vi
    @Published var toastMessage: String? = nil

    // MobileGestalt Editor
    @Published var customDeviceName: String = ""
    @Published var selectedDeviceSubtype: String = "Mặc định (iPhone 16 Pro Max - 2868)"
    @Published var aodVibrancy: Double = 1.0
    @Published var gestaltFeatures: [GestaltFeature] = [
        GestaltFeature(key: "ArtworkDeviceSubType", title: "Dynamic Island / Kiểu thiết bị", category: "Giao diện thiết bị", isEnabled: false),
        GestaltFeature(key: "RDARStatusBarFix", title: "Sửa thanh trạng thái RDAR", category: "Giao diện thiết bị", isEnabled: false),
        GestaltFeature(key: "AlwaysOnDisplay", title: "Màn hình luôn bật (AOD)", category: "Màn hình", isEnabled: false),
        GestaltFeature(key: "TapToWake", title: "Chạm để bật", category: "Màn hình", isEnabled: true),
        GestaltFeature(key: "AppleIntelligence", title: "Apple Intelligence", category: "Điều kiện", isEnabled: false),
        GestaltFeature(key: "DisableRegionLock", title: "Tắt khóa khu vực", category: "Điều kiện", isEnabled: false),
        GestaltFeature(key: "StageManager", title: "Stage Manager", category: "Hệ thống", isEnabled: false),
        GestaltFeature(key: "iPadOSMode", title: "Chế độ iPadOS", category: "Hệ thống", isEnabled: false),
        GestaltFeature(key: "InstalliPadApps", title: "Cài ứng dụng iPad", category: "Hệ thống", isEnabled: false),
        GestaltFeature(key: "ActionButton", title: "Nút Tác vụ (Action Button)", category: "Phần cứng", isEnabled: false),
        GestaltFeature(key: "CameraButton", title: "Nút Camera (Camera Control)", category: "Phần cứng", isEnabled: false),
        GestaltFeature(key: "ApplePencil", title: "Hỗ trợ Apple Pencil", category: "Phần cứng", isEnabled: false),
        GestaltFeature(key: "BootChime", title: "Âm thanh khởi động (Boot Chime)", category: "Phần cứng", isEnabled: false),
        GestaltFeature(key: "ChargeLimit", title: "Giới hạn sạc 80%", category: "Phần cứng", isEnabled: false),
        GestaltFeature(key: "CrashDetection", title: "Phát hiện va chạm", category: "Phần cứng", isEnabled: false),
        GestaltFeature(key: "MetalHUD", title: "Metal HUD", category: "Tính năng nội bộ", isEnabled: false),
        GestaltFeature(key: "InternalStorage", title: "Bộ nhớ nội bộ", category: "Tính năng nội bộ", isEnabled: false),
        GestaltFeature(key: "SecurityResearch", title: "Nghiên cứu bảo mật", category: "Tính năng nội bộ", isEnabled: false)
    ]

    // Danh sách Container Ứng dụng (MHA-C2 / FilzaSlop)
    @Published var containers: [AppContainerItem] = [
        AppContainerItem(
            bundleID: "com.dts.freefireth",
            name: "Free Fire",
            cacheSizeMB: 348.5,
            files: [
                FileEntry(name: "Documents", relativePath: "Documents", isDirectory: true, sizeBytes: 4096, modifiedDate: Date()),
                FileEntry(name: "Library", relativePath: "Library", isDirectory: true, sizeBytes: 4096, modifiedDate: Date()),
                FileEntry(name: "tmp", relativePath: "tmp", isDirectory: true, sizeBytes: 4096, modifiedDate: Date()),
                FileEntry(name: "com.dts.freefireth.plist", relativePath: "Library/Preferences/com.dts.freefireth.plist", isDirectory: false, sizeBytes: 18432, modifiedDate: Date())
            ]
        ),
        AppContainerItem(
            bundleID: "com.dts.freefiremax",
            name: "Free Fire MAX",
            cacheSizeMB: 512.0,
            files: [
                FileEntry(name: "Documents", relativePath: "Documents", isDirectory: true, sizeBytes: 4096, modifiedDate: Date()),
                FileEntry(name: "Library", relativePath: "Library", isDirectory: true, sizeBytes: 4096, modifiedDate: Date()),
                FileEntry(name: "AssetBundle", relativePath: "Documents/AssetBundle", isDirectory: true, sizeBytes: 1048576, modifiedDate: Date())
            ]
        ),
        AppContainerItem(
            bundleID: "com.lemon.lvoverseas",
            name: "CapCut",
            cacheSizeMB: 824.2,
            files: [
                FileEntry(name: "Documents", relativePath: "Documents", isDirectory: true, sizeBytes: 4096, modifiedDate: Date()),
                FileEntry(name: "Library/Caches", relativePath: "Library/Caches", isDirectory: true, sizeBytes: 864026624, modifiedDate: Date())
            ]
        ),
        AppContainerItem(
            bundleID: "com.apple.PosterBoard",
            name: "PosterBoard (System)",
            cacheSizeMB: 42.1,
            files: [
                FileEntry(name: "Extensions", relativePath: "Library/Application Support/PRBPosterExtensionDataStore/61/Extensions", isDirectory: true, sizeBytes: 4096, modifiedDate: Date())
            ]
        )
    ]

    // Dự án Patch (.3105)
    @Published var patchProjects: [PatchProject] = [
        PatchProject(
            name: "Unlock 120FPS & High Graphics",
            author: "YangJiii",
            targetBundle: "com.dts.freefireth",
            isPrivate: false,
            isPasswordProtected: false,
            passwordHash: "",
            isApplied: false,
            rules: [
                PatchRule(targetBundle: "com.dts.freefireth", destinationRelativePath: "Documents/MReplays/config.bin", replacementFileName: "config_120fps.bin", fileSize: 32768),
                PatchRule(targetBundle: "com.dts.freefireth", destinationRelativePath: "Library/Preferences/com.dts.freefireth.plist", replacementFileName: "ff_ultra.plist", fileSize: 8192)
            ]
        ),
        PatchProject(
            name: "CapCut Pro Workspace Patch",
            author: "IOSVN",
            targetBundle: "com.lemon.lvoverseas",
            isPrivate: true,
            isPasswordProtected: true,
            passwordHash: "3105",
            isApplied: false,
            rules: [
                PatchRule(targetBundle: "com.lemon.lvoverseas", destinationRelativePath: "Library/Preferences/vip_cache.json", replacementFileName: "vip_unlocked.json", fileSize: 4096)
            ]
        )
    ]

    // Wallpaper Lab (.tendies)
    @Published var wallpaperPackages: [WallpaperPackage] = [
        WallpaperPackage(name: "iOS 18 Flux Dynamic.tendies", descriptorCount: 4, sizeString: "28.4 MB", isInstalled: true),
        WallpaperPackage(name: "Pride Radiance Animated.tendies", descriptorCount: 2, sizeString: "16.1 MB", isInstalled: false),
        WallpaperPackage(name: "Cyberpunk Neon Depth.tendies", descriptorCount: 3, sizeString: "34.8 MB", isInstalled: false)
    ]

    // Hướng dẫn (Guides)
    @Published var guides: [GuideItem] = [
        GuideItem(
            title: "Hướng dẫn cấp quyền Kernel Exploit & Sandbox",
            subtitle: "Hỗ trợ iOS 16.0–18.7.1 và iOS 26.0–26.6.1",
            category: "Hệ thống",
            content: "1. Đảm bảo Astra được ký bằng chứng chỉ doanh nghiệp (eSign/Feather).\n2. Mở tab Hệ thống và nhấn Chạy Kernel Exploit.\n3. Khi trạng thái chuyển sang Đã hoạt động, mở trình chỉnh sửa Gestalt.",
            likes: 128
        ),
        GuideItem(
            title: "Cách tạo và sử dụng gói Patch .3105",
            subtitle: "Thay thế tệp an toàn trong container ứng dụng",
            category: "Patch",
            content: "Mỗi quy tắc lưu bundle identifier của app (ví dụ com.dts.freefireth) và đường dẫn tương đối bên trong data container. File gốc luôn được sao lưu tự động trước lần ghi đầu tiên.",
            likes: 94
        ),
        GuideItem(
            title: "Cài đặt hình nền động .tendies vào PosterBoard",
            subtitle: "Tự phân giải com.apple.PosterBoard",
            category: "Wallpaper Lab",
            content: "Sau khi nhấn Áp dụng gói .tendies, hãy mở trình đa nhiệm và vuốt lên để đóng PosterBoard. Mở lại màn hình khóa để nhận bộ sưu tập mới.",
            likes: 76
        )
    ]

    @Published var logs: [SessionLogEntry] = []

    init() {
        log("Khởi tạo Astra v2.4.2 (Build 242) — Ứng dụng phát triển bởi YangJiii.")
        log("Hỗ trợ ghi trực tiếp: iOS 16.0–18.7.1 & iOS 26.0–26.6.1. AirLift: iOS 18.7.2+ / iOS 27.2b2.")
    }

    func log(_ message: String) {
        let nextIndex = logs.count + 1
        let entry = SessionLogEntry(index: nextIndex, timestamp: Date(), message: message)
        DispatchQueue.main.async {
            self.logs.insert(entry, at: 0)
        }
    }

    func showToast(_ message: String) {
        withAnimation(.spring()) {
            toastMessage = message
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.8) {
            withAnimation(.easeOut) {
                if self.toastMessage == message {
                    self.toastMessage = nil
                }
            }
        }
    }

    func runKernelExploit() {
        guard kernelStatus != .running else { return }
        kernelStatus = .running
        log("Đang chạy kernel exploit (kexploit_opa334 / FilzaSlop sandbox escape)...")
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
            self.kernelStatus = .active
            self.sandboxAccessGranted = true
            self.log("Đã xác minh quyền truy cập ngoài sandbox (R/W com.apple.mobilegestaltcache & MHA-C2).")
            self.showToast("Đã cấp quyền exploit & sandbox!")
        }
    }

    func applyGestaltChanges() {
        guard sandboxAccessGranted else {
            showToast("Hãy cấp quyền sandbox trước.")
            return
        }
        let enabledCount = gestaltFeatures.filter { $0.isEnabled }.count
        let bytesWritten = 49152 + enabledCount * 256
        log("Đang ghi \(enabledCount) tính năng vào com.apple.mobilegestaltcache (\(bytesWritten) byte)...")
        showToast("Hoàn tất! Đã áp dụng \(bytesWritten) byte.")
    }

    func revertOriginalGestalt() {
        for index in gestaltFeatures.indices {
            gestaltFeatures[index].isEnabled = false
        }
        customDeviceName = ""
        log("Đã khôi phục bản gốc tệp MobileGestalt. Nhấn KHỞI ĐỘNG LẠI để áp dụng.")
        showToast("Đã khôi phục bản gốc MobileGestalt.")
    }
}
