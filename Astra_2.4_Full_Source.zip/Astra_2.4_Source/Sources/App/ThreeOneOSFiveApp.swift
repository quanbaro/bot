import SwiftUI

@main
struct ThreeOneOSFiveApp: App {
    @StateObject private var appState = AppState()
    @AppStorage("astra.onboarding.completed") private var onboardingCompleted: Bool = true

    var body: some Scene {
        WindowGroup {
            if onboardingCompleted {
                AppTabNavigation()
                    .environmentObject(appState)
                    .preferredColorScheme(.dark)
            } else {
                OnboardingFlowView(isCompleted: $onboardingCompleted)
                    .environmentObject(appState)
                    .preferredColorScheme(.dark)
            }
        }
    }
}
