#!/bin/bash
set -e

echo "[*] Đang tạo Astra.xcodeproj bằng XcodeGen..."
xcodegen generate

echo "[*] Đang biên dịch Astra (Release - iphoneos)..."
xcodebuild -project Astra.xcodeproj \
           -scheme Astra \
           -configuration Release \
           -sdk iphoneos \
           -derivedDataPath build \
           CODE_SIGN_IDENTITY="" \
           CODE_SIGNING_REQUIRED=NO \
           CODE_SIGNING_ALLOWED=NO \
           clean build

echo "[*] Đang đóng gói Astra_2.4_new.ipa..."
rm -rf Payload Astra_2.4_new.ipa
mkdir -p Payload
cp -r build/Build/Products/Release-iphoneos/Astra.app Payload/

# Nhúng Assets.car và AppIcon gốc trích xuất từ IPA vào gói .app
if [ -f "Resources/Assets.car" ]; then
    cp -f Resources/Assets.car Payload/Astra.app/
fi
if [ -f "Resources/AppIcon60x60@2x.png" ]; then
    cp -f Resources/AppIcon60x60@2x.png Payload/Astra.app/
fi
if [ -f "Resources/AppIcon76x76@2x~ipad.png" ]; then
    cp -f Resources/AppIcon76x76@2x~ipad.png Payload/Astra.app/
fi

zip -r9 Astra_2.4_new.ipa Payload
rm -rf Payload
echo "[+] Đã tạo thành công: Astra_2.4_new.ipa"
