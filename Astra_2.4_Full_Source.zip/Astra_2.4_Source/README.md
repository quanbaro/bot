# Astra 2.4 (ThreeOneOSFiveApp) — Full iOS Source Code

Mã nguồn đầy đủ tái tạo toàn bộ cấu trúc, tính năng và tài nguyên gốc của **Astra 2.4 (`com.astra.app`)**:
- **Hệ thống (`DashboardView` & `GestaltEditorView`)**: Quản lý Kernel Exploit (`kexploit_opa334` / `FilzaSlop` sandbox escape), kết nối `AirLift` & Pairing file (`.mobiledevicepairing`), trình chỉnh sửa `com.apple.mobilegestaltcache` (Dynamic Island, Stage Manager, Apple Intelligence, AOD, Action Button, Camera Button, Boot Chime, Charge Limit 80%, Metal HUD, RDAR Fix...).
- **Tệp (`AppDataBrowserView` & `FileBrowserView`)**: Duyệt container ứng dụng qua `MHA-C2`, quản lý đa thẻ (`FilesTabStrip`), nén/giải nén ZIP, thay thế tệp (`FileReplacementService`), và quản lý `Workspace Astra`.
- **Patch (`PatchProjectsView` & `PatchPackageCodec`)**: Tạo, mở khóa, nhập/xuất gói `.3105`, hỗ trợ Patch riêng tư (ẩn đường dẫn & bundle), Áp dụng patch, Đặt lại theo gói và Khôi phục file gốc.
- **Dọn dẹp (`CleanerView`)**: Quét và dọn dẹp `Library/Caches` và `tmp` của các ứng dụng.
- **Hình nền (`WallpaperLabView`)**: Tự phân giải `com.apple.PosterBoard`, nhập và cài đặt gói hình nền `.tendies`, khôi phục/reset descriptor.
- **Cài đặt (`SettingsView` & `GuidesView`)**: Đổi ngôn ngữ (`Tiếng Việt`, `English`, `简体中文`), tạo Sandbox Token, thông tin tương thích iOS.
- **Tài nguyên gốc (`Resources/`)**: Đã trích xuất và nhúng nguyên bản `Assets.car`, `AppIcon60x60@2x.png`, `AppIcon76x76@2x~ipad.png` và 537 khóa ngôn ngữ `Localizable.strings` (`vi.lproj`, `en.lproj`, `zh-Hans.lproj`) từ file `Astra_2.4_new.ipa`.

## Cách Build ra file `.ipa`

### Cách 1: Build tự động bằng GitHub Actions (Không cần máy Mac)
1. Tải toàn bộ nội dung trong thư mục `Astra_2.4_Source` lên một Repository trên GitHub.
2. Vào tab **Actions** trên GitHub -> chọn workflow **Build Astra 2.4 IPA** -> nhấn **Run workflow** (hoặc workflow sẽ tự chạy khi push lên nhánh `main`).
3. Chờ 1–2 phút và tải file `Astra_2.4_new.ipa` tại mục **Artifacts**.

### Cách 2: Build trực tiếp trên macOS (Xcode / XcodeGen)
```bash
chmod +x build_ipa.sh
./build_ipa.sh
```
File `Astra_2.4_new.ipa` sẽ được xuất ra ngay tại thư mục gốc của dự án.
